module.exports = function(importName) {
    return 'test/lib/' + importName.toUpperCase();
}